
package org.ie.dao;

import java.sql.*;

/**
 * Contains jdbc logic to remove employee registry from database table
 */
public class JdbcEmployeeRemove {
    private static final String REMOVE_EMPLOYEE="DELETE FROM EMPDETAILS WHERE PERSONID=? AND USERNAME=?";

    /**
     * Performs remove operation of employee record from the
     * Empdetails table by validating employee id and employee username
     * @param employeeId
     * @param employeeUserName
     * @return true if record is removed else returns false
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public   boolean removeEmployee(int employeeId,String employeeUserName) throws SQLException, ClassNotFoundException {
        PreparedStatement preparedStatement;
        ResultSet resultSet;
        Connection connection=null;
        int count;

        //loads the driver class for mysql data base
       // Class.forName("com.mysql.jdbc.Driver");
        //creates connection object
        //connection = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123");
        //Creating pre compiled statement object with query
        preparedStatement=connection.prepareStatement(REMOVE_EMPLOYEE);
        //set query parameters
        preparedStatement.setInt(1,employeeId);
        preparedStatement.setString(2,employeeUserName);
        //execute the query
        count= preparedStatement.executeUpdate();
        return count!=0;
    }

  /*  public static void main(String[] args) throws SQLException, ClassNotFoundException {
      boolean b= removeEmployee(2,"praveen1437");
        System.out.println(b);
    }*/
}
