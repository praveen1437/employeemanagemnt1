package org.ie.dao;

import org.ie.dto.EmployeeDto;
import org.omg.CORBA.PRIVATE_MEMBER;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JdbcFetchEmployeeDetails {
    private final static String FETCH_DATA = "SELECT * FROM EMPDETAILS WHERE USERNAME=?";
    private final static String FETCH_ALL_DATA = "SELECT * FROM EMPDETAILS";

    public EmployeeDto fetchEmpDetail(String user) throws SQLException {
        PreparedStatement preparedStatement;
        ResultSet resultSet;
        EmployeeDto employee = null;
       // try (Connection con = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123")) {
         try(Connection con=DriverManager.getConnection("","","")){
            preparedStatement = con.prepareStatement(FETCH_DATA);
            preparedStatement.setString(1, user);
            resultSet = preparedStatement.executeQuery();
            //process the resultset
            if (!resultSet.next()) {
                return null;
            }
            while (resultSet.next()) {
                employee = new EmployeeDto();
                employee.setId(resultSet.getInt(1));
                employee.setEmployeeName(resultSet.getString(2));
                employee.setAddress(resultSet.getString(3));
                employee.setDesignation(resultSet.getString(4));
                employee.setUserName(resultSet.getString(5));
                employee.setPassWord(resultSet.getString(6));
                //System.out.println(resultSet.getInt(1)+"  "+resultSet.getString(2)+" "+resultSet.getString(3)+" "+resultSet.getString(4)+" "+resultSet.getString(5)+" "+resultSet.getString(6));

            }

        }
        return employee;
    }

    public List fetchEmpDetailS() throws SQLException {
        PreparedStatement preparedStatement;
        ResultSet resultSet;
        EmployeeDto employee = null;
        List<EmployeeDto> employeeDtoList = new ArrayList<>();
       // try (Connection con = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123")) {
          try(Connection con=DriverManager.getConnection("","","")){
            preparedStatement = con.prepareStatement(FETCH_ALL_DATA);
            resultSet = preparedStatement.executeQuery();
            //process the resultset
            if (!resultSet.next()) {
                return null;
            }

            while (resultSet.next()) {
                employee = new EmployeeDto();
                employee.setId(resultSet.getInt(1));
                employee.setEmployeeName(resultSet.getString(2));
                employee.setAddress(resultSet.getString(3));
                employee.setDesignation(resultSet.getString(4));
                employee.setUserName(resultSet.getString(5));
                employee.setPassWord(resultSet.getString(6));
                employeeDtoList.add(employee);
                //System.out.println(resultSet.getInt(1)+"  "+resultSet.getString(2)+" "+resultSet.getString(3)+" "+resultSet.getString(4)+" "+resultSet.getString(5)+" "+resultSet.getString(6));

            }

        }
        return employeeDtoList;
    }
}
