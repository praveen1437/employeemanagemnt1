package org.ie.dao;

import org.ie.dto.EmployeeDto;

import java.sql.*;

public class JdbcEmployeeLoginCheck {
    private final static String CHECK_QUERY = "SELECT PASSWORD FROM EMPDETAILS WHERE USERNAME=?";
    private final static String ID_USERNAME_CHECK = "SELECT * FROM EMPDETAILS WHERE PERSONID=? AND USERNAME=?";

    public static boolean checkPassword(String user, String password) throws SQLException, ClassNotFoundException {
        PreparedStatement ps;
        ResultSet rs;
        String pwd = "notfound";
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection con = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123")) {
            ps = con.prepareStatement(CHECK_QUERY);
            ps.setString(1, user);
            rs = ps.executeQuery();
            while (rs.next()) {
                pwd = rs.getString(1);
                System.out.println(pwd);
            }
            if (pwd.equals("notfound")) {
                throw new IllegalArgumentException("wrong user name");
            }
            return pwd.equals(password);
        }
    }

    public boolean checkIDAndUserName(int id, String userName) throws ClassNotFoundException, SQLException {
        PreparedStatement ps;
        ResultSet rs;
        boolean b;
        String pwd = "notfound";
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123");
        ps = con.prepareStatement(ID_USERNAME_CHECK);
        ps.setInt(1, id);
        ps.setString(2, userName);
       //execute the query
        rs=ps.executeQuery();
        if(!rs.next()){
            throw new IllegalArgumentException("wrong user name or id");
        }
        else{
            b=true;
        }
        return b;
    }

    }
