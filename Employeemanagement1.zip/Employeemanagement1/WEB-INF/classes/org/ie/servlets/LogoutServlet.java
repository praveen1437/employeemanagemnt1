package org.ie.servlets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class LogoutServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter printWriter;
        //get print writer object
        printWriter=res.getWriter();
        //set content type
        res.setContentType("text/html");
        //invalidate the session
        req.getSession().invalidate();
        printWriter.println("<h1>you are successfully logged out</h1>");
        printWriter.println("<a href=Home1.html>Home</a>");

    }
}
