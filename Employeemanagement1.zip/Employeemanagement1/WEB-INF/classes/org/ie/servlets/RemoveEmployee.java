package org.ie.servlets;

import org.ie.dao.JdbcEmployeeRemove;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Handles the request which comes from the
 * removeemployee.html file
 */
public class RemoveEmployee extends HttpServlet {
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        JdbcEmployeeRemove jdbcEmployeeRemove = new JdbcEmployeeRemove();
        config.getServletContext().setAttribute("remove", jdbcEmployeeRemove);
    }

    /**
     * Gets the data from the removeEmployee.html file.
     * removes the record only if the id and username matches with
     * the data already present in the table.
     *
     * @param req
     * @param res
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter pw;
        int employeeId;
        String employeeUserName;
        JdbcEmployeeRemove jdbcEmployeeRemove;
        boolean b = false;
        //create printwriter object to display content on the browser
        pw = res.getWriter();
        //set content type to browser
        res.setContentType("text/html");
        //get the values from removeemployee.html
        employeeId = Integer.parseInt(req.getParameter("eId"));
        employeeUserName = req.getParameter("EmployeeUserName");
        //get jdbcEmployeeRemove class object from servlet context
        jdbcEmployeeRemove = (JdbcEmployeeRemove) getServletContext().getAttribute("remove");
        //calling method to remove the record from the data base
        try {
            b = jdbcEmployeeRemove.removeEmployee(employeeId, employeeUserName);
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
            pw.println("<h1> Unable to perform The opeartion </h1>");
            pw.print("<a href=home.html>Home</a>");
        }

        if (b){
            pw.println("<h1> Record is removed successfully</h1>");
            pw.print("<a href=home.html>Home</a>");
            pw.print("<a href=totalemployeedetails>Home</a>");

        }
        else{
            pw.println("<h1> Unable to perform The opeartion </h1>");
            pw.print("<a href=home.html>Home</a>");
        }

    }

}