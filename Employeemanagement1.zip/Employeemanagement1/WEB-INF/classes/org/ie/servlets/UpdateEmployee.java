package org.ie.servlets;

import org.ie.dao.JdbcEmployeeLoginCheck;
import org.ie.dao.JdbcEmployeeRemove;
import org.ie.dao.JdbcFetchEmployeeDetails;
import org.ie.dao.JdbcUpdateEmployee;
import org.ie.dto.EmployeeDto;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * servlet to process the update request
 */
public class UpdateEmployee extends HttpServlet {


    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        UpdateEmployee updateEmployee= new UpdateEmployee();
        config.getServletContext().setAttribute("update",updateEmployee);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter pw;
        int employeeId;
        String employeeUserName;
        JdbcUpdateEmployee jdbcUpdateEmployee;
        JdbcEmployeeLoginCheck jdbcEmployeeLoginCheck;
        RequestDispatcher requestDispatcher;
        boolean isPresent=false;
        boolean updateResult=false;
        //create printwriter object to display content on the browser
        pw = res.getWriter();
        //set content type to browser
        res.setContentType("text/html");
        //get the values from removeemployee.html
        employeeId = Integer.parseInt(req.getParameter("eId"));
        employeeUserName = req.getParameter("EmployeeUserName");
        //get  jdbc login check object from context object
        jdbcEmployeeLoginCheck= (JdbcEmployeeLoginCheck) getServletContext().getAttribute("logincheck");
        //check whether the given id and username is correct or not
        try {
           isPresent= jdbcEmployeeLoginCheck.checkIDAndUserName(employeeId,employeeUserName);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }catch (IllegalArgumentException e){
            pw.println("<h1>Wrong user name or password</h1>");
            requestDispatcher = req.getRequestDispatcher("/updateemployee");
            requestDispatcher.include(req,res);
        }
        if (!isPresent){
            pw.println("<h1>Wrong user name or password</h1>");
            requestDispatcher = req.getRequestDispatcher("/updateemployee");
            requestDispatcher.include(req,res);
        }
        else{
            jdbcUpdateEmployee = (JdbcUpdateEmployee) getServletContext().getAttribute("update");
            requestDispatcher=req.getRequestDispatcher("/updateemployee");
            requestDispatcher.include(req,res);
            if(req.getParameter("update").equals("update employee")){
                //get servlet context object and get jdbcemployee fetch object
               JdbcFetchEmployeeDetails jdbcFetchEmployeeDetails= (JdbcFetchEmployeeDetails) getServletContext().getAttribute("fetchEmployeeDetails");
                EmployeeDto employeeDto=null;
                try {
                    //get employee object which is present in data base
                     employeeDto= jdbcFetchEmployeeDetails.fetchEmpDetail(employeeUserName);
                    // get the values from update form
                    String name= req.getParameter("sname");
                    String address= req.getParameter("sAddress");
                    String designation= req.getParameter("sDesignation");
                    EmployeeDto updateDto= new EmployeeDto();
                    updateDto.setEmployeeName(name);
                    updateDto.setDesignation(designation);
                    updateDto.setAddress(address);
                    updateResult=jdbcUpdateEmployee.updateEmployeeDetails(employeeDto,updateDto);
                } catch (SQLException | ClassNotFoundException e) {
                    e.printStackTrace();
                }


            }
        }
       if(updateResult){
           pw.println("<h1> record updated Successfully</h1>");
       }
       else{
           pw.println("<h1> record updation failed");
       }
        pw.println("<a href=Login.html>HOME</a>");
        pw.println("<a href=/showdetails>Show All Employees</a>");

    }
}
