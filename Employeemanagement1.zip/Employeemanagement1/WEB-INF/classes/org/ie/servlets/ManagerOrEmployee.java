package org.ie.servlets;

import org.ie.dao.JdbcEmployeeLoginCheck;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * to redirect the request to manager and employee
 * by validating
 */

public class ManagerOrEmployee extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter printWriter;
        String submitValue;
        JdbcEmployeeLoginCheck jdbcEmployeeLoginCheck;
        boolean isValid=false;
        HttpSession session;
        RequestDispatcher requestDispatcher;
        //get printwriter object
        printWriter=res.getWriter();
        //set content type
        res.setContentType("text/html");
        //redirect request by checking submit button value
        submitValue=req.getParameter("more");
        if(submitValue.equals("managerlogin")){
            jdbcEmployeeLoginCheck= (JdbcEmployeeLoginCheck) getServletContext().getAttribute("loginCheck");
            try {
               isValid= jdbcEmployeeLoginCheck.checkPassword(req.getParameter("ManagerUserName"),req.getParameter("password"));
               if(isValid){
                   session=req.getSession();
                   session.setAttribute("managerUserName",req.getParameter("ManagerUserName"));
                   session.setAttribute("password",req.getParameter("password"));
                   requestDispatcher = req.getRequestDispatcher("managerhome.html");
                   requestDispatcher.forward(req,res);

               }
               else{
                   requestDispatcher = req.getRequestDispatcher("managerlogin.html");
                   requestDispatcher.forward(req,res);
               }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                printWriter.println("<h1>something went wrong</h1>");
            }
        }
        else{
            jdbcEmployeeLoginCheck= (JdbcEmployeeLoginCheck) getServletContext().getAttribute("loginCheck");
            try {
               isValid= jdbcEmployeeLoginCheck.checkPassword(req.getParameter("EmployeeUserName"),req.getParameter("password"));
                if(isValid){
                    session=req.getSession();
                    session.setAttribute("employeeUserName",req.getParameter("EmployeeUserName"));
                    session.setAttribute("password",req.getParameter("password"));
                    requestDispatcher = req.getRequestDispatcher("managerhome.html");
                    requestDispatcher.forward(req,res);
                }
                else{
                    requestDispatcher = req.getRequestDispatcher("employeelogin.html");
                    requestDispatcher.forward(req,res);
                }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                printWriter.println("<h1>something went wrong</h1>");
            }
        }


    }
}
