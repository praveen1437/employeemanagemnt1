package org.ie.listeners;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

public class RequestListener implements ServletRequestListener {
    @Override
    public void requestDestroyed(ServletRequestEvent servletRequestEvent) {
        System.out.println("listener destroyed");
        System.out.println(servletRequestEvent.getServletContext().getAttribute("loginCheck"));
    }

    @Override
    public void requestInitialized(ServletRequestEvent servletRequestEvent) {
        System.out.println("listener created");
        System.out.println(servletRequestEvent.getServletContext().getAttribute("remove"));

    }
}
