package listeners;

import org.ie.dao.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ContextListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        //set all jdbc class object to context object
        JdbcEmployeeRemove jdbcEmployeeRemove= new JdbcEmployeeRemove();
        JdbcEmployeeLoginCheck jdbcEmployeeLoginCheck= new JdbcEmployeeLoginCheck();
        JdbcFetchEmployeeDetails jdbcFetchEmployeeDetails= new JdbcFetchEmployeeDetails();
        JdbcInsertEmployee jdbcInsertEmployee= new JdbcInsertEmployee();
        JdbcUpdateEmployee jdbcUpdateEmployee= new JdbcUpdateEmployee();
        //get servlet context object
        ServletContext servletContext=servletContextEvent.getServletContext();
        //set attributes to servlet context
        servletContext.setAttribute("remove",jdbcEmployeeRemove);
        servletContext.setAttribute("loginCheck",jdbcEmployeeLoginCheck);
        servletContext.setAttribute("fetchEmployeeDetails",jdbcFetchEmployeeDetails);
        servletContext.setAttribute("insert",jdbcInsertEmployee);
        servletContext.setAttribute("update",jdbcUpdateEmployee);
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        //get servlet context object
        ServletContext servletContext=servletContextEvent.getServletContext();
        //set attributes to servlet context
        servletContext.setAttribute("remove",null);
        servletContext.setAttribute("loginCheck",null);
        servletContext.setAttribute("fetchEmployeeDetails",null);
        servletContext.setAttribute("insert",null);
        servletContext.setAttribute("update",null);

    }
}
